import React from "react";
import AuthTokenForm from "../components/AuthTokenForm";

const HomePage = () => {
    return (
        <>
            <AuthTokenForm />
        </>
    );
};

export default HomePage;
