export const ETH_DECIMALS = Math.pow(10, 18);
