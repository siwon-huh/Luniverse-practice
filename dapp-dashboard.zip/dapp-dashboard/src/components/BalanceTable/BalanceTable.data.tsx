export const tableHeaders = [
    "#",
    "Name",
    "Symbol",
    "Contract Address",
    "Amount",
];
export const paginationOptions = [10, 25, 50, 100];
