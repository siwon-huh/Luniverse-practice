export const LogoImgSrc = "/assets/luniverse_symbol.png";
export const LogoWords = "Luniverse";
